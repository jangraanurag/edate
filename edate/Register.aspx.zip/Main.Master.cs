﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace edate
{
    public partial class Main : System.Web.UI.MasterPage
    {
        King king=new King();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                
                if (Request.Cookies["userName"] != null)
                {
                    DataSet ds = king.getdataset("select * from [Username] where [Username]='" + Request.Cookies["userName"].Value + "'");
                    if (ds.Tables[0].Rows.Count > 0)
                    {
                        DataRow dr = ds.Tables[0].Rows[0];
                        string image = "";
                        if (!(dr["image"].ToString() == "" || dr["image"].Equals(DBNull.Value)))
                        {
                            image = "./images/profile/" + dr["image"].ToString();
                        }
                        string link = king.getsitename(false) + "Profile-detail.aspx?user=" + Request.Cookies["userName"].Value;
                        string chatid = Request.Cookies["userName"].Value.ToString();
                        if(ds.Tables[0].Rows[0]["UUD"] != DBNull.Value)
                        {
                            chatid= ds.Tables[0].Rows[0]["UUD"].ToString();
                        }
                        string chat = @"<script>
                  var chat_appid = '56199';
                  var chat_auth = '1fe0643e991b23524694bd5a05624644';
                    var chat_id = '" + chatid + @"';
                    var chat_name = '" + Request.Cookies["userName"].Value.ToString() + @"';
                    var chat_avatar = '" + image + @"';
                    var chat_link = '" + link + @"';
                    var chat_role = 'User (Logged-in)';



    var chat_css = document.createElement('link'); chat_css.rel = 'stylesheet'; chat_css.type = 'text/css'; chat_css.href = 'https://fast.cometondemand.net/'+chat_appid+'x_xchat.css';
    document.getElementsByTagName(""head"")[0].appendChild(chat_css);
    var chat_js = document.createElement('script'); chat_js.type = 'text/javascript'; chat_js.src = 'https://fast.cometondemand.net/' + chat_appid + 'x_xchat.js'; var chat_script = document.getElementsByTagName('script')[0]; chat_script.parentNode.insertBefore(chat_js, chat_script);
 </script>";
                        ltchat.Text = chat;
                        myaccount_parent.InnerHtml = Request.Cookies["userName"].Value.ToString() + " <i class='fa fa-angle-down fa-indicator'></i>";
                        myaccount_parent.Visible = true;
                        myaccount_child.Visible = true;
                        primary_side.Visible = false;
                    }
                    else
                    {
                        myaccount_parent.Visible = false;
                        myaccount_child.Visible = false;
                        primary_side.Visible = true;
                    }


                }
                else
                {
                    myaccount_parent.Visible = false;
                    myaccount_child.Visible = false;
                    primary_side.Visible = true;
                }
            }
        }
        protected void lblogout_Click(object sender, EventArgs e)
        {
            Response.Cookies["userName"].Value = null;
            Response.Cookies["Email"].Value = null;

            myaccount_parent.Visible = false;
            myaccount_child.Visible = false;
            primary_side.Visible = true;

        }
    }
}