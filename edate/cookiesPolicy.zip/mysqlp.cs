﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using MySql.Data;
using System.Data;



namespace edate
{
    internal class mysqlp
    {
        MySqlConnection cn = new MySqlConnection(@"Persist Security Info=False;database=edatewor_db;server=edateworld.com;user id=edatewor_db;Password=Eworld@2021;pooling = false; convert zero datetime=True");
        public DataSet getdataset(string query)
        {
            
            DataSet ds = new DataSet();
            if (cn.State == ConnectionState.Closed)
            {
                cn.Open();
            }
            MySqlDataAdapter da = new MySqlDataAdapter(query, cn);
            da.Fill(ds);
            cn.Close();
            return ds;
        }
        public DataTable getdatatable(string query)
        {
            DataTable dt = new DataTable();
            DataSet ds = new DataSet();
            if (cn.State == ConnectionState.Closed)
            {
                cn.Open();
            }
            MySqlDataAdapter da = new MySqlDataAdapter(query, cn);
            da.Fill(ds);
            dt = ds.Tables[0];
            cn.Close();
            return dt;
        }

    }
}
